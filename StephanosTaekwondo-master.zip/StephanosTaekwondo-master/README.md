# Stephano's Taekwondo Institute

Build Restful CRUD API for an institue using Spring MVC, Oracle and Hibernate.

## Requirements

1. Java - 1.8.x

2. Maven - 3.3.9


